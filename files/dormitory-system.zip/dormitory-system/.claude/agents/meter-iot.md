---
name: meter-iot
description: สร้าง Meter Service สำหรับเชื่อมมิเตอร์ไฟฟ้า/น้ำผ่าน Modbus, MQTT, OCR เก็บข้อมูล time-series ใน TimescaleDB ตรวจจับการใช้ไฟผิดปกติ ส่ง real-time ผ่าน WebSocket และคำนวณหน่วยรายเดือนสำหรับออกบิล หัวใจของระบบจัดการหอพัก
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
---

# Meter Service Agent — IoT & Time-series

หัวใจของระบบ — รับข้อมูลจากมิเตอร์ทุก 15 นาที วิเคราะห์ และส่งให้ billing/notification

## Database Models

### `meters` (PostgreSQL)
- id (UUID PK), serial_number (unique), room_id (FK)
- meter_type (enum: electricity_1p, electricity_3p, water)
- protocol (enum: modbus_rtu, modbus_tcp, mqtt, manual)
- connection_config (JSON: host, port, slave_id, topic, etc.)
- rate_per_unit (Decimal), service_charge
- baseline_reading, baseline_date
- last_reading, last_reading_at
- status (enum: active, offline, maintenance, decommissioned)
- low_threshold, high_threshold (สำหรับ anomaly)

### `meter_readings` (TimescaleDB hypertable)
- ts (TIMESTAMPTZ, partition key)
- meter_id (UUID)
- reading (Decimal) — ค่ารวมจากมิเตอร์
- delta (Decimal) — ส่วนที่ใช้ตั้งแต่ reading ก่อน
- voltage, current, power_factor (สำหรับมิเตอร์ไฟ)
- source (enum: modbus, mqtt, ocr, manual)
- raw_payload (JSONB)

### `meter_alerts`
- id, meter_id (FK), alert_type (enum: anomaly_high, anomaly_low, offline, threshold_exceeded, leak_suspected)
- severity (low, medium, high, critical)
- detected_at, resolved_at, message, acknowledged_by

### `meter_periods` (สรุปรายเดือนสำหรับ billing)
- id, meter_id, period (YYYY-MM)
- start_reading, end_reading, units_used, amount
- closed_at, closed_by

## Architecture Components

### 1. MQTT Subscriber (`mqtt_worker.py`)
```python
# Subscribe to: meter/+/reading
# Payload: {"reading": 1234.56, "voltage": 220, "ts": "2025-..."}
async def on_message(topic, payload):
    meter_id = topic.split('/')[1]
    data = json.loads(payload)
    await save_reading(meter_id, data)
    await detect_anomaly(meter_id, data)
    await broadcast_websocket(meter_id, data)
```

### 2. Modbus Polling Worker (`modbus_worker.py`)
- Loop ทุก 15 นาที
- เช็คทุก meter ที่ protocol = modbus_*
- อ่านผ่าน pymodbus, save → เหมือน MQTT path
- Handle connection errors → mark offline + alert

### 3. OCR Endpoint (Gemini fallback)
- POST `/api/meters/{id}/manual` — รับรูปภาพมิเตอร์
- ส่งไป Gemini API พร้อม prompt:
  ```
  อ่านตัวเลขที่แสดงบนหน้าจอมิเตอร์ไฟฟ้านี้
  ตอบเป็น JSON: {"reading": 12345.67, "confidence": 0.95}
  ```
- บันทึก reading + source = ocr

### 4. Anomaly Detection
- ใช้ rolling 30-day average + 3σ
- ถ้า delta ใน 1 ชม. > avg + 3σ → alert anomaly_high
- ถ้า meter ส่งค่าต่อเนื่องตอนกลางคืน (00:00-05:00) ไม่ลดลง → leak_suspected (สำหรับน้ำ)
- ถ้าไม่มีข้อมูลเข้ามา > 1 ชม. → mark offline + alert

### 5. WebSocket Broadcast
- Endpoint `/ws/meters/{room_id}`
- Push real-time reading ทันทีที่มี new data
- Authentication ผ่าน JWT query param

## API Endpoints

- GET `/api/meters` — list ทั้งหมด (admin)
- GET `/api/meters/{id}` — รายละเอียด + last reading
- GET `/api/meters/{id}/readings?from=&to=&granularity=` — time-series
- GET `/api/meters/{id}/current` — reading ล่าสุด
- GET `/api/meters/{id}/usage?period=` — สรุปรายเดือน
- POST `/api/meters/{id}/manual` — บันทึก manual + OCR
- POST `/api/meters/{id}/calibrate` — ตั้ง baseline ใหม่
- POST `/api/meters/{id}/close-period` — ปิดงวด สิ้นเดือน
- GET `/api/meters/alerts?status=open` — ดู alerts
- POST `/api/meters/alerts/{id}/acknowledge`
- WS `/ws/meters/{room_id}` — real-time stream

## TimescaleDB Setup

```sql
-- Hypertable
SELECT create_hypertable('meter_readings', 'ts', chunk_time_interval => INTERVAL '7 days');

-- Continuous aggregate รายชั่วโมง
CREATE MATERIALIZED VIEW meter_hourly
WITH (timescaledb.continuous) AS
SELECT
  meter_id,
  time_bucket('1 hour', ts) AS bucket,
  MAX(reading) - MIN(reading) AS delta_kwh,
  AVG(voltage) AS avg_voltage
FROM meter_readings
GROUP BY meter_id, bucket;

-- Compression (ลดขนาด ~90%)
ALTER TABLE meter_readings SET (
  timescaledb.compress,
  timescaledb.compress_segmentby = 'meter_id'
);

SELECT add_compression_policy('meter_readings', INTERVAL '30 days');
```

## Period Closing Flow (สิ้นเดือน)

```python
# Celery task รัน 23:59 ของวันสุดท้ายของเดือน
async def close_meter_period(month: str):
    for meter in active_meters:
        start = month + '-01 00:00'
        end = next_month + '-01 00:00'
        start_reading = await get_reading_at(meter.id, start)
        end_reading = await get_reading_at(meter.id, end)
        units = end_reading - start_reading
        amount = units * meter.rate_per_unit + meter.service_charge

        await db.insert(meter_periods, {
            'meter_id': meter.id,
            'period': month,
            'start_reading': start_reading,
            'end_reading': end_reading,
            'units_used': units,
            'amount': amount,
            'closed_at': now()
        })

        await mq.publish('meter.month_closed', {
            'meter_id': meter.id,
            'period': month,
            'units': units,
            'amount': amount
        })
```

## Events

### Publish
- `meter.reading_received` — ทุก reading ใหม่ (high volume, Redis pub/sub)
- `meter.anomaly_detected` — เมื่อเจอ anomaly
- `meter.offline` — meter ไม่ส่งข้อมูล
- `meter.month_closed` — ปิดงวด
- `meter.threshold_exceeded` — ใช้เกินที่ตั้งไว้

### Subscribe
- `contract.created` — สร้าง baseline
- `room.created` — register meter ใหม่

## Hardware Integration Spec

### Eastron SDM630 (3-phase, Modbus RTU)
- Total Energy register: 0x0156 (8 bytes, IEEE 754)
- Voltage L1: 0x0000
- Read interval: ทุก 15 นาที

### MQTT Topic Convention
- `meter/{meter_serial}/reading` — sensor → broker
- `meter/{meter_serial}/control` — broker → sensor (config)
- `meter/{meter_serial}/status` — online/offline LWT

## Acceptance Criteria

- [ ] Modbus polling ทำงานกับ pymodbus mock simulator
- [ ] MQTT subscriber รับข้อมูลแล้วบันทึก TimescaleDB
- [ ] OCR endpoint รับรูปแล้วได้ค่าตัวเลข (test กับรูปจริง)
- [ ] Anomaly detection trigger alert ได้ถูกต้อง
- [ ] WebSocket ส่ง real-time ไป frontend ได้
- [ ] Continuous aggregate query เร็ว < 50ms
- [ ] Period closing ทำงานครบ — emit event ถูกต้อง
- [ ] Compression policy ทำงาน
- [ ] Test coverage ≥ 80% (ใช้ pytest-asyncio + pymodbus mock)

## Mock Hardware สำหรับ Dev

สร้าง `tools/meter_simulator.py` — script จำลองมิเตอร์ส่ง MQTT ทุก 15 นาที (สำหรับทดสอบโดยไม่ต้องมี hardware จริง)
