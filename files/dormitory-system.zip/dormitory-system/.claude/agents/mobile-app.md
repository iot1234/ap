---
name: mobile-app
description: สร้าง Mobile App ด้วย Flutter 3 + Riverpod สำหรับผู้เช่า (ดูบิล จ่ายเงิน แจ้งซ่อม) และพนักงาน (รับงานซ่อม) ของระบบหอพัก รองรับทั้ง iOS และ Android จาก codebase เดียว มี push notification ผ่าน FCM และ BLE unlock
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
---

# Mobile App Agent — Flutter App

สร้าง mobile app ที่ผู้เช่าและพนักงาน (ช่าง/แม่บ้าน) ใช้ — codebase เดียวรองรับทั้ง iOS และ Android

## Tech Stack

- Flutter 3.24+
- Dart 3.5+
- Riverpod 2.x (state management)
- Dio (HTTP client)
- go_router (navigation)
- hive (local storage)
- firebase_messaging (push)
- flutter_blue_plus (BLE unlock)
- mobile_scanner (QR)
- image_picker + image_cropper
- fl_chart (charts)
- intl (i18n - locale: th_TH)
- flutter_local_notifications

## App Structure

```
mobile/
├── lib/
│   ├── main.dart
│   ├── app.dart
│   ├── core/
│   │   ├── api/             ← API client + interceptors
│   │   ├── auth/
│   │   ├── theme/
│   │   ├── routing/
│   │   ├── localization/
│   │   └── utils/
│   ├── features/
│   │   ├── auth/            ← login, OTP, biometric
│   │   ├── home/            ← dashboard
│   │   ├── bills/           ← list, detail, payment
│   │   ├── payments/        ← QR, history
│   │   ├── meters/          ← consumption charts
│   │   ├── maintenance/     ← report, history
│   │   ├── access/          ← unlock door, QR for guest
│   │   ├── notifications/
│   │   ├── profile/
│   │   └── staff/           ← สำหรับช่าง: รับงาน, อัปเดตสถานะ
│   ├── shared/
│   │   ├── widgets/         ← reusable
│   │   ├── models/
│   │   └── providers/
│   └── l10n/
│       ├── app_th.arb
│       └── app_en.arb
├── android/
├── ios/
├── assets/
│   ├── fonts/
│   ├── images/
│   └── animations/          ← Lottie files
└── pubspec.yaml
```

## User Roles & Flows

### ผู้เช่า (Tenant Role)

#### Bottom Navigation
1. **หน้าแรก** — บิลปัจจุบัน, ค่าไฟวันนี้, ข่าวประกาศ
2. **บิล** — รายการบิล + ปุ่มจ่าย
3. **แจ้งซ่อม** — สร้าง ticket, ดูสถานะ
4. **เพิ่มเติม** — โปรไฟล์, สัญญา, แจ้งเตือน, ตั้งค่า

#### Pages
- **Login Screen:** เบอร์โทร + OTP / LINE login / biometric
- **Dashboard:** Card บิลล่าสุด, KPI ค่าไฟเดือนนี้, แจ้งเตือนล่าสุด, quick actions
- **Bill List:** filter (ทั้งหมด/ค้าง/จ่ายแล้ว), pull-to-refresh
- **Bill Detail:** breakdown items, QR PromptPay (full screen), upload สลิป, ประวัติชำระ
- **Payment Flow:** กดจ่าย → แสดง QR → กล้องอ่านสลิปบันทึก (optional) → ส่งสลิปอัปโหลด
- **Meter Consumption:** กราฟ today/week/month, เปรียบเทียบ, anomaly warning
- **Maintenance Report:** form: ประเภท, รายละเอียด, รูป (สูงสุด 5 รูป), urgent toggle
- **Maintenance Status:** timeline ของ ticket, รูป before/after, rating หลังเสร็จ
- **Access:** "เปิดประตู" ปุ่ม BLE unlock, สร้าง QR แขก, ประวัติเข้า-ออก
- **Profile:** ข้อมูลส่วนตัว, สัญญา, เปลี่ยน LINE/email
- **Settings:** notification preferences, language, biometric, dark mode

### พนักงาน (Staff Role)

#### Bottom Navigation
1. **งานของฉัน** — งานที่ assign ให้
2. **งานทั้งหมด** — รับงานเพิ่ม
3. **เพิ่มเติม** — ตารางงาน, ประวัติ, โปรไฟล์

#### Pages
- **My Tasks:** list งานที่ยังไม่จบ + sort by priority
- **Task Detail:** รายละเอียด, รูปจาก tenant, แผนที่ห้อง, ปุ่ม Start/Complete
- **In Progress:** อัปโหลดรูป during, บันทึก parts ที่ใช้, comment
- **Complete Form:** รูป after, resolution notes, parts cost, ส่งให้ tenant rate
- **Schedule:** calendar view ของ scheduled tasks
- **Stats:** completed this month, avg rating, SLA performance

## Key Features

### Authentication
- Phone + OTP (ใช้ Firebase Auth)
- LINE Login (ใช้ flutter_line_sdk)
- Biometric (face/fingerprint) สำหรับ re-login
- JWT stored ใน flutter_secure_storage

### Real-time Updates
- FCM push notifications สำหรับ:
  - บิลใหม่ (เปิด → bill detail)
  - แจ้งซ่อมรับเรื่อง / มีช่าง / เสร็จแล้ว
  - แจ้งเตือนสำคัญ (น้ำไม่ไหล, ดับไฟ)
- WebSocket connection สำหรับ active screens (meter consumption)

### BLE Unlock
- App scan BLE beacons ของประตูที่อยู่ใกล้ (RSSI < -70 dBm)
- เมื่อกดปุ่ม "เปิดประตู" → app sign challenge ด้วย private key (ใน secure enclave)
- ส่ง challenge ไป door controller ผ่าน BLE characteristic
- Door controller verify → unlock + ส่ง event ไป backend
- Fallback: QR code generated dynamically (ใช้ in-app camera scan ที่ door)

### QR Payment
- Display PromptPay QR เต็มจอ
- Tap to share, save image
- Auto-poll status — เมื่อ webhook confirmed → success animation

### Slip Upload
- ใช้ image_picker จากกล้องหรือแกลลอรี่
- Image_cropper ปรับขอบ
- Upload progress indicator
- Result page: status (verified/pending/failed)

### Push Notification Categories
- bill (high importance)
- maintenance (medium)
- access (high — alerts)
- announcement (low — broadcast)

ผู้ใช้ตั้งค่าแยกได้ใน settings

## Theme & Design

### Light Mode
- Primary: warm terracotta (#B8722A)
- Background: cream paper (#F7F3EC)
- Card: white with subtle warm tint
- Typography: Sarabun (body) + Fraunces (display)

### Dark Mode
- Background: deep walnut (#15140F)
- Card: warm dark (#1E1C16)
- Accent: glowing amber

### Components
- Custom `BottomSheet` แบบ rounded แบบ native iOS
- `SkeletonLoader` ทุก loading state
- `ErrorView` พร้อม retry button
- `EmptyState` พร้อม illustration (Lottie)

## Offline Support

- Hive local cache สำหรับ:
  - User profile
  - Last 30 bills
  - Last 50 maintenance tickets
- Show cached data เมื่อ offline + banner "Offline mode"
- Queue actions (เช่น report maintenance) → sync เมื่อ online

## Internationalization

- ภาษาไทย (default), English
- Date: ใช้ พ.ศ. ในไทย (พฤษภาคม 2569)
- Currency: ฿1,234.56
- Phone format: 081-234-5678

## Firebase Setup

- FCM (push)
- Firebase Auth (phone OTP)
- Crashlytics (error tracking)
- Analytics (user behavior)

## App Icon & Branding

- Icon: monogram "ห" บน background warm terracotta
- Splash screen: minimal — logo + ชื่อ + loading dots

## Build & Deploy

- Android: Gradle, signing config
- iOS: Xcode project, capabilities (BLE, push, camera)
- Code signing setup
- Build flavors: dev, staging, production
- Fastlane scripts สำหรับ release

## Acceptance Criteria

- [ ] Build ผ่านทั้ง Android และ iOS
- [ ] Login + OTP ทำงาน
- [ ] ทุกหน้า render ถูกต้อง พร้อม mock + real data
- [ ] FCM push ทำงาน (test ใน Firebase console)
- [ ] BLE unlock ทำงาน (test กับ ESP32 mock)
- [ ] QR payment + slip upload ทำงาน end-to-end
- [ ] Offline mode ทำงาน — cached data + queue actions
- [ ] Dark mode สวยงามทุกหน้า
- [ ] Locale switch ทำงาน th/en
- [ ] Performance: 60 fps scrolling
- [ ] App size < 30 MB
- [ ] Test coverage ≥ 70% (widget + integration tests)

## Integration Points

- API ทุก backend service
- LINE SDK สำหรับ login + sharing
- Firebase services
- BLE protocol with door controllers
