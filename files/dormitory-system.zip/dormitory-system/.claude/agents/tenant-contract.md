---
name: tenant-contract
description: สร้าง Tenant Service สำหรับจัดการ Building, Room, Tenant, Contract ของระบบหอพัก รวมถึง check-in/check-out flow, สัญญาดิจิทัล e-Signature, และ tenant history เรียกใช้หลังจาก backend-core เสร็จแล้ว
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
---

# Tenant & Contract Service Agent

รับผิดชอบ service หลักที่จัดการข้อมูลทุกอย่างเกี่ยวกับห้อง ผู้เช่า และสัญญา เป็น single source of truth ของระบบ

## Database Models (`core` schema)

### `buildings`
- id (UUID PK), name, address, total_floors, total_rooms, created_at

### `rooms`
- id (UUID PK), building_id (FK), room_number (unique per building), floor, size_sqm
- room_type (enum: standard, premium, penthouse)
- base_rent (Decimal), deposit_months (default 2)
- status (enum: vacant, occupied, reserved, maintenance, blocked)
- bed_type, view, amenities (JSON array)
- photos (JSON array of S3 keys)
- meter_id (FK to meters table)

### `tenants`
- id (UUID PK), citizen_id (encrypted), full_name, nickname, gender
- date_of_birth, phone, email, line_user_id (unique)
- address (current, permanent), occupation, workplace
- emergency_contact (JSON: name, relation, phone)
- documents (JSON array of S3 keys: ID card, photo, etc.)
- is_active, blacklist_reason, created_at

### `contracts`
- id (UUID PK), contract_number (unique), room_id (FK), tenant_id (FK)
- start_date, end_date, monthly_rent, deposit, water_rate, electricity_rate
- payment_due_day (default 5), late_fee_rate (default 0.015)
- status (enum: draft, active, expired, terminated, renewed)
- signed_pdf_s3_key, esignature_data (JSON)
- baseline_meter_reading, baseline_water_reading
- terminated_at, termination_reason, refund_amount
- created_by (user_id), created_at

### `tenant_history`
- id, tenant_id (FK), action (check_in, check_out, transfer, blacklist)
- room_id, contract_id, performed_by, notes, occurred_at

## API Endpoints

### Buildings
- GET `/api/buildings` — ลิสต์ทั้งหมด + occupancy stats
- POST `/api/buildings` — สร้างใหม่ (admin only)
- GET `/api/buildings/{id}/floor-map` — ผังชั้นพร้อมสถานะห้อง

### Rooms
- GET `/api/rooms?building_id=&floor=&status=&min_rent=&max_rent=` — search filter
- GET `/api/rooms/{id}` — รายละเอียด + ผู้เช่าปัจจุบัน + ประวัติ
- POST `/api/rooms` — สร้างห้องใหม่
- PUT `/api/rooms/{id}` — แก้ไข
- POST `/api/rooms/{id}/photos` — อัปโหลดรูป (multipart, ส่ง MinIO)
- DELETE `/api/rooms/{id}/photos/{photo_id}`
- PUT `/api/rooms/{id}/status` — เปลี่ยนสถานะ (มี audit)

### Tenants
- GET `/api/tenants?search=&active=` — search ชื่อ/เบอร์/citizen_id
- POST `/api/tenants` — เพิ่มใหม่ (validate citizen_id format)
- GET `/api/tenants/{id}` — profile + active contract + history
- PUT `/api/tenants/{id}` — แก้ไข
- POST `/api/tenants/{id}/documents` — อัปโหลด ID card/photo
- POST `/api/tenants/{id}/blacklist` — ใส่ blacklist
- GET `/api/tenants/{id}/history` — ประวัติทั้งหมด

### Contracts
- POST `/api/contracts` — สร้างสัญญา (auto-generate contract number)
- GET `/api/contracts/{id}/pdf` — สร้าง PDF สัญญา (WeasyPrint จาก Jinja2 template)
- POST `/api/contracts/{id}/sign` — e-Signature (รับ base64 PNG ของลายเซ็น)
- POST `/api/contracts/{id}/checkin` — บันทึก baseline meter, ออก RFID, ส่ง event
- POST `/api/contracts/{id}/checkout` — คำนวณค่าใช้จ่ายสุดท้าย, refund deposit
- POST `/api/contracts/{id}/terminate` — ยกเลิกก่อนกำหนด
- POST `/api/contracts/{id}/renew` — ต่อสัญญา (สร้าง contract ใหม่ status = renewed_from)
- GET `/api/contracts/expiring?days=30` — สัญญาใกล้หมด

## Business Logic — บังคับใช้

1. **Check-in flow:**
   - ตรวจสอบว่าห้อง vacant หรือ reserved
   - บันทึก baseline meter (ดึงจาก meter-service)
   - เปลี่ยนสถานะห้อง → occupied
   - สร้าง RFID card request → access-service
   - ส่ง event `tenant.checked_in` → notification-service ส่ง LINE
   - บันทึก tenant_history

2. **Check-out flow:**
   - คำนวณ pro-rate rent ถ้าย้ายออกกลางเดือน
   - อ่านค่ามิเตอร์ปัจจุบัน
   - สร้างบิลสุดท้าย (ส่ง event ให้ billing-service)
   - หักจาก deposit, คำนวณ refund
   - ปิด RFID card
   - เปลี่ยนสถานะห้อง → vacant
   - ส่ง event `tenant.checked_out`

3. **Contract validation:**
   - end_date > start_date
   - tenant ไม่มี active contract อื่น (ยกเว้นย้ายห้องในเครือเดียวกัน)
   - ตรวจ blacklist ก่อนสร้าง

4. **Auto-expire:**
   - Celery task รายวัน — เปลี่ยน status เป็น `expired` ถ้า end_date < today
   - แจ้งเตือนล่วงหน้า 30/15/7 วัน ผ่าน notification-service

## Events

### Publish (ส่งออก)
- `tenant.created`, `tenant.updated`, `tenant.blacklisted`
- `contract.created`, `contract.signed`, `contract.terminated`, `contract.expiring_soon`
- `tenant.checked_in`, `tenant.checked_out`
- `room.status_changed`

### Subscribe (รับเข้า)
- `payment.completed` — อัปเดต financial status ของ tenant
- `meter.baseline_set` — confirm baseline บันทึกแล้ว

## Acceptance Criteria

- [ ] Models มี relationship ครบถ้วน, Alembic migration ผ่าน
- [ ] CRUD ทุก endpoint ทำงานครบ — มี validation, error handling
- [ ] PDF generation ทำงาน — สัญญาเช่าออกมาสวยงาม ภาษาไทยถูกต้อง
- [ ] Check-in/out flow ทำงาน end-to-end (mock service อื่น)
- [ ] Search รองรับ pagination, sorting
- [ ] Photo upload ไป MinIO ได้, generate signed URL ได้
- [ ] Test coverage ≥ 80%
- [ ] OpenAPI docs ครบ

## Integration Points

- **Meter Service:** ดึง baseline reading, ส่ง subscription ไปฟัง meter events
- **Billing Service:** ส่ง contract details เพื่อสร้างบิลรายเดือน
- **Access Service:** request/revoke RFID card
- **Notification Service:** ส่ง events ทุก action สำคัญ
