---
name: web-frontend
description: สร้าง Web Admin Dashboard ด้วย Next.js 15 App Router + TypeScript + TanStack Query + Tailwind + shadcn/ui + Chart.js สำหรับเจ้าของและแอดมินจัดการหอพักทั้งหมด รวมถึงผังอาคาร 3D, ดูค่ามิเตอร์ real-time ผ่าน WebSocket, จัดการบิล, และ reports
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
---

# Web Frontend Agent — Next.js Admin Dashboard

สร้าง web admin dashboard ที่เจ้าของหอพัก/แอดมินใช้จัดการระบบทั้งหมด

## Tech Stack

- Next.js 15 (App Router, Server Components)
- TypeScript strict mode
- TanStack Query v5 (server state)
- Zustand (client state)
- Tailwind CSS + shadcn/ui
- Chart.js + react-chartjs-2
- React Hook Form + Zod validation
- Three.js (สำหรับ 3D building view)
- date-fns (locale: th)
- next-intl (i18n)

## Page Structure (App Router)

```
web/src/app/
├── (auth)/
│   ├── login/page.tsx
│   └── forgot-password/page.tsx
├── (dashboard)/
│   ├── layout.tsx           ← sidebar + header
│   ├── page.tsx             ← Dashboard home (KPIs + alerts)
│   ├── building/
│   │   ├── page.tsx         ← 3D building view + 2D fallback
│   │   ├── floor/[n]/page.tsx
│   │   └── room/[id]/page.tsx
│   ├── tenants/
│   │   ├── page.tsx         ← list + search
│   │   ├── new/page.tsx
│   │   └── [id]/page.tsx    ← profile + history + contracts
│   ├── contracts/
│   │   ├── page.tsx
│   │   ├── new/page.tsx
│   │   ├── [id]/page.tsx
│   │   └── expiring/page.tsx
│   ├── bills/
│   │   ├── page.tsx         ← list + filter
│   │   ├── generate/page.tsx ← batch generate UI
│   │   ├── [id]/page.tsx    ← detail + payment history
│   │   └── overdue/page.tsx
│   ├── payments/
│   │   ├── page.tsx
│   │   ├── reconcile/page.tsx ← manual matching tool
│   │   └── [id]/page.tsx
│   ├── meters/
│   │   ├── page.tsx         ← dashboard real-time
│   │   ├── [id]/page.tsx    ← detail + chart
│   │   └── alerts/page.tsx
│   ├── maintenance/
│   │   ├── page.tsx         ← Kanban board
│   │   ├── [id]/page.tsx
│   │   └── calendar/page.tsx
│   ├── access/
│   │   ├── page.tsx         ← live access feed
│   │   ├── cards/page.tsx
│   │   ├── doors/page.tsx
│   │   └── logs/page.tsx
│   ├── notifications/
│   │   ├── page.tsx         ← history
│   │   ├── templates/page.tsx
│   │   └── broadcast/page.tsx
│   ├── reports/
│   │   ├── page.tsx         ← dashboard
│   │   ├── revenue/page.tsx
│   │   ├── occupancy/page.tsx
│   │   ├── energy/page.tsx
│   │   └── custom/page.tsx
│   ├── staff/
│   │   ├── page.tsx
│   │   └── [id]/page.tsx
│   └── settings/
│       ├── building/page.tsx
│       ├── rates/page.tsx
│       ├── billing/page.tsx
│       └── integrations/page.tsx
└── api/
    └── ws/route.ts          ← WebSocket proxy
```

## Key Features per Page

### Dashboard (Home)
- KPI cards: Total revenue this month, Occupancy rate, Open tickets, Overdue bills
- Real-time alerts list (จาก WebSocket)
- Today's check-ins/outs
- Energy consumption chart (today vs yesterday)
- Quick actions: ออกบิล, แจ้งเตือน, ดูสัญญาใกล้หมด

### Building View (3D)
- Three.js render อาคาร 5 ชั้น isometric
- คลิกชั้นเพื่อ zoom in
- คลิกห้องเพื่อ open detail panel
- สีตามสถานะ (vacant/occupied/reserved/maintenance)
- Toggle: 3D view / 2D floor plan / List view
- Real-time update เมื่อ status เปลี่ยน

### Tenants Page
- Data table (TanStack Table) — sort, filter, paginate
- Search instant (debounce 300ms)
- Bulk actions: export, send broadcast
- Click row → drawer slide-in with profile
- Profile page: photo, info, contracts, payments timeline, maintenance history
- Action buttons: edit, blacklist, view contract, generate bill

### Contracts Page
- List view + Calendar view (สำหรับ end_date)
- Filter: status, room, tenant
- "Expiring soon" view — เน้นสีแดงถ้า < 7 วัน
- Detail page: contract terms, signature image, PDF download, action history
- New contract form: multi-step wizard (เลือกห้อง → เลือกผู้เช่า → ตั้งเงื่อนไข → ตรวจ → เซ็น)

### Bills Page
- Filter chips: All / Issued / Paid / Overdue / Voided
- Aged receivable summary at top
- Bulk select + export Excel
- Detail page: items, payment timeline, send reminder button
- Generate page: เลือกเดือน → preview ทุกห้อง → confirm → batch run
- PDF preview modal

### Meters Page (เด่น)
- Grid ของห้องทั้งหมด แสดง current reading + sparkline 24h
- WebSocket update real-time
- คลิกห้อง → modal กราฟละเอียด (1d/7d/30d/1y) — Chart.js line chart
- Anomaly alerts banner ด้านบน
- Comparison mode: เลือก 5 ห้อง → overlay กราฟ
- Export: CSV ของช่วงเวลาที่เลือก

### Maintenance Kanban
- Columns: Open / Assigned / In Progress / Awaiting Parts / Completed
- Drag & drop เพื่อเปลี่ยน status (optimistic update)
- คลิก ticket → detail drawer พร้อมรูป before/after
- Filter by: priority, category, assigned_to
- Calendar view alternative

### Access Live Feed
- Real-time list ของ access events (WebSocket)
- แต่ละ entry: tenant name, door, time, granted/denied
- Click → expand video clip จาก CCTV
- Filter: door, denied only, suspicious
- Manual override panel: emergency unlock door, lock all

### Reports
- Dashboard cards พร้อม mini charts
- คลิกเข้าไปดูเต็ม
- Export buttons (Excel, PDF) ทุกหน้า
- Date range picker (preset: this month, last month, this year, custom)
- Compare with previous period toggle

## Component Library (shadcn/ui based)

```
web/src/components/
├── ui/                  ← shadcn base (button, dialog, etc.)
├── layout/
│   ├── Sidebar.tsx
│   ├── TopBar.tsx
│   └── Breadcrumb.tsx
├── dashboard/
│   ├── KPICard.tsx
│   ├── AlertsList.tsx
│   └── QuickActions.tsx
├── building/
│   ├── Building3D.tsx   ← Three.js
│   ├── FloorPlan2D.tsx
│   └── RoomCard.tsx
├── tenants/
│   ├── TenantTable.tsx
│   ├── TenantDrawer.tsx
│   └── TenantForm.tsx
├── meters/
│   ├── MeterCard.tsx
│   ├── ConsumptionChart.tsx
│   └── AnomalyBadge.tsx
├── maintenance/
│   ├── KanbanBoard.tsx
│   └── TicketCard.tsx
├── shared/
│   ├── DataTable.tsx
│   ├── DateRangePicker.tsx
│   ├── StatusBadge.tsx
│   └── Empty.tsx
└── providers/
    ├── QueryProvider.tsx
    ├── ThemeProvider.tsx
    └── WebSocketProvider.tsx
```

## State Management Strategy

- **Server state:** TanStack Query — auto refetch, optimistic updates, cache
- **Form state:** React Hook Form
- **UI state:** Zustand (sidebar collapsed, theme, etc.)
- **Real-time:** WebSocketProvider context → publish updates to TanStack Query cache

## API Client Setup

```typescript
// web/src/lib/api.ts
export const api = {
  tenants: createService('/api/tenants'),
  contracts: createService('/api/contracts'),
  bills: createService('/api/bills'),
  // ...
}

// Auto-attach JWT, refresh token on 401, retry idempotent requests
```

## Authentication

- Login page → POST /auth/login → store JWT in httpOnly cookie
- Middleware (`middleware.ts`) ตรวจ auth ก่อนเข้า dashboard routes
- Auto-refresh token before expire
- Role-based UI: hide menu items ที่ user ไม่มีสิทธิ์

## i18n & Localization

- Language: Thai (default), English
- Date format: 30 เม.ย. 2569 (BE)
- Currency: ฿1,234.56
- Number format: ภาษาไทยใช้ comma separator

## Design Tokens

```css
:root {
  --primary: 24 82% 47%;      /* burnt orange */
  --secondary: 195 30% 45%;
  --background: 38 30% 96%;
  --foreground: 30 10% 12%;
  --success: 130 35% 40%;
  --warning: 35 70% 55%;
  --danger: 5 65% 50%;
  --font-display: 'Fraunces', serif;
  --font-sans: 'Sarabun', sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
}
```

## Performance Requirements

- Lighthouse score ≥ 90
- First Contentful Paint < 1.5s
- Bundle size < 500KB gzipped
- Code splitting ทุก route
- Image optimization ผ่าน next/image
- Static generation สำหรับ pages ที่เป็นไปได้

## Acceptance Criteria

- [ ] ทุกหน้าใน sitemap render ได้ ไม่มี error
- [ ] Login flow ทำงาน + token refresh
- [ ] WebSocket connect และอัปเดต real-time
- [ ] 3D building view โหลดและ interact ได้
- [ ] Forms ทุกที่มี validation (Zod) + error display
- [ ] Data tables sort, filter, paginate ทำงาน
- [ ] Charts render ถูกต้องด้วย mock data + real data
- [ ] Responsive: ใช้ได้บน tablet (≥ 768px)
- [ ] Dark mode toggle ทำงานทุกหน้า
- [ ] Lighthouse ≥ 90 ทุก category
- [ ] E2E test (Playwright) ครอบคลุม critical paths

## Integration Points

- เรียก backend services ทั้งหมด (REST + WebSocket)
- Auth flow ผ่าน auth-service
- File upload ผ่าน MinIO (presigned URL)
