---
name: maintenance-access
description: สร้าง 2 services ที่เกี่ยวข้อง — Maintenance Service สำหรับระบบแจ้งซ่อม ticket assignment SLA tracking และ Access Control Service สำหรับ RFID QR door lock CCTV log การเข้า-ออกของระบบหอพัก
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
---

# Maintenance & Access Service Agent

รับผิดชอบ 2 services พร้อมกัน เพราะมีโครงสร้างคล้ายกัน

---

# PART 1: Maintenance Service

## Database Models

### `maintenance_requests`
- id (UUID PK), ticket_number (MT-YYYYMM-NNNN unique)
- room_id (FK), tenant_id (FK), reported_by (user_id)
- category (enum: electrical, plumbing, ac, furniture, structural, internet, security, other)
- priority (enum: low, medium, high, critical)
- status (enum: open, assigned, in_progress, awaiting_parts, completed, cancelled, reopened)
- title, description, location_in_room
- assigned_to (user_id), assigned_at
- scheduled_at, started_at, completed_at
- sla_target (timestamp), sla_breached (bool)
- resolution_notes, parts_used (JSON)
- cost (Decimal), tenant_responsible (bool)
- rating (1-5), rating_comment, rated_at
- created_at, updated_at

### `maintenance_photos`
- id, request_id (FK), photo_type (enum: before, during, after, parts)
- s3_key, uploaded_by, uploaded_at, ai_categorization (JSON)

### `maintenance_costs`
- id, request_id (FK), item_name, quantity, unit_price, amount
- supplier, receipt_s3_key

### `maintenance_sla_rules`
- priority, response_time_hours, resolution_time_hours

## API Endpoints

### Tenant-facing
- POST `/api/maintenance` — สร้าง ticket (ผ่าน LINE Bot หรือ App)
- GET `/api/maintenance/my` — ticket ของ tenant
- GET `/api/maintenance/{id}` — รายละเอียด
- POST `/api/maintenance/{id}/photos`
- POST `/api/maintenance/{id}/rate` — ให้คะแนนหลังเสร็จ
- POST `/api/maintenance/{id}/reopen` — เปิดใหม่ถ้ายังไม่ได้แก้

### Admin/Staff-facing
- GET `/api/maintenance?status=&priority=&assigned_to=&category=`
- PUT `/api/maintenance/{id}/assign` — มอบหมายช่าง
- PUT `/api/maintenance/{id}/status` — อัปเดต status
- POST `/api/maintenance/{id}/costs` — บันทึกค่าใช้จ่าย
- POST `/api/maintenance/{id}/charge-tenant` — ส่งค่าใช้จ่ายเข้าบิล tenant
- GET `/api/maintenance/dashboard` — สรุป open tickets, SLA breach, avg rating

## Auto-categorization (Gemini AI)

เมื่อสร้าง ticket → ส่งข้อความ + รูป (ถ้ามี) ไป Gemini เพื่อ:
1. แยกประเภท (category)
2. ประเมิน priority
3. แนะนำช่างเฉพาะทาง

```python
prompt = """ผู้เช่าหอพักรายงานปัญหา:
"{description}"
[+ รูปภาพ ถ้ามี]

ตอบเป็น JSON:
- category: electrical/plumbing/ac/furniture/structural/internet/security/other
- priority: low/medium/high/critical
- estimated_hours: ช่วงเวลาประเมินซ่อม (เช่น "2-4 ชั่วโมง")
- recommended_specialty: สาขาช่างที่ควร assign
- safety_concern: bool (เร่งด่วนเรื่องความปลอดภัยไหม)"""
```

## SLA Tracking

| Priority | Response | Resolution |
|----------|----------|------------|
| Critical | 1 hour   | 4 hours    |
| High     | 4 hours  | 24 hours   |
| Medium   | 24 hours | 3 days     |
| Low      | 3 days   | 7 days     |

Celery task รายชั่วโมง:
- เช็ค ticket ที่ approaching SLA (< 1 ชม. ก่อนหมด)
- ถ้าหมดแล้วและยังไม่เริ่ม → mark sla_breached, alert manager

## Events Maintenance

### Publish
- `maintenance.created`, `maintenance.assigned`
- `maintenance.in_progress`, `maintenance.completed`
- `maintenance.sla_breached`, `maintenance.rated`

### Subscribe
- `tenant.checked_out` — auto-cancel pending tickets

---

# PART 2: Access Control Service

## Database Models

### `rfid_cards`
- id (UUID PK), card_uid (unique, hex), tenant_id (FK)
- card_number (printed label)
- issued_at, issued_by, deactivated_at, deactivated_reason
- active (bool), is_temporary (bool)
- valid_from, valid_until
- access_zones (JSON array: ['main_door', 'parking', 'gym', 'pool'])

### `door_devices`
- id, device_id (unique), name, location
- floor, controller_type (enum: esp32, raspi, commercial)
- ip_address, mqtt_topic, last_seen
- door_type (main_entrance, room_door, common_area, parking_gate)
- emergency_unlock (bool, default false)

### `access_logs` (high volume — partition by month)
- id (BIGSERIAL), ts (TIMESTAMPTZ)
- card_id (FK nullable for QR), tenant_id (nullable)
- door_id (FK), method (enum: rfid, qr, mobile_ble, pin, emergency)
- granted (bool), reason (string ถ้า denied)
- direction (enum: in, out)
- cctv_clip_s3_key (link to recorded video)

### `temporary_qr_codes`
- id, code (JWT), generated_by, generated_for
- valid_from, valid_until, max_uses, used_count
- access_zones, is_revoked

## API Endpoints

### Verification (เรียกจาก ESP32 controller)
- POST `/api/access/verify` — body: {card_uid, door_id} → response: {granted, tenant_name?}
- POST `/api/access/verify-qr` — body: {qr_token, door_id}
- POST `/api/access/verify-mobile` — body: {tenant_token, door_id, ble_signature}

### Card Management
- POST `/api/access/cards` — ออกบัตรใหม่
- PUT `/api/access/cards/{id}/deactivate`
- PUT `/api/access/cards/{id}/zones` — แก้สิทธิ์ zone
- GET `/api/access/cards?tenant_id=&active=`

### QR Generation
- POST `/api/access/qr/generate` — สร้าง QR ชั่วคราว (รับ {valid_hours, max_uses, zones})
- POST `/api/access/qr/{id}/revoke`

### Logs & Monitoring
- GET `/api/access/logs?tenant_id=&door_id=&from=&to=`
- GET `/api/access/logs/anomaly` — entries ที่น่าสงสัย (เช่น พยายามเข้าหลายครั้ง)
- POST `/api/access/doors/{id}/emergency-unlock` — manager only
- POST `/api/access/doors/{id}/lock` — ปิดด่วน
- WS `/ws/access/live` — real-time event stream

## Verification Logic

```python
async def verify_access(card_uid, door_id):
    # 1. หา card
    card = await get_card_by_uid(card_uid)
    if not card or not card.active:
        log_denied('card_not_found_or_inactive')
        return DENIED

    # 2. ตรวจ valid period
    if not (card.valid_from <= now <= card.valid_until):
        log_denied('expired')
        return DENIED

    # 3. ตรวจ zone permission
    door = await get_door(door_id)
    if door.access_zone not in card.access_zones:
        log_denied('zone_not_allowed')
        return DENIED

    # 4. ตรวจ overdue payment (auto-disable feature)
    tenant = card.tenant
    if await has_overdue_payment(tenant.id, days=30):
        log_denied('overdue_payment')
        await notify_admin(tenant.id, 'access_blocked_overdue')
        return DENIED

    # 5. Anti-passback check
    last_log = await get_last_access(card.id)
    if last_log and same_direction(last_log, current_attempt):
        log_denied('anti_passback')
        return DENIED

    # 6. ผ่านทุกข้อ → grant
    log_granted()
    await mq.publish('access.granted', {...})
    return GRANTED
```

## CCTV Integration

- เมื่อมี access event → trigger NVR API บันทึก clip 30 วินาที (-15 ถึง +15 จาก event)
- Save clip URL ลง access_logs.cctv_clip_s3_key
- Frontend แสดง video player ใน access log detail

## MQTT Topic Convention (Door Controllers)

- `door/{door_id}/access` — controller report event
- `door/{door_id}/command` — server send unlock/lock
- `door/{door_id}/status` — heartbeat (online/offline LWT)

## Events Access

### Publish
- `access.granted`, `access.denied`
- `access.suspicious_activity` — หลายครั้งติดกัน
- `door.offline`, `door.online`
- `card.deactivated`

### Subscribe
- `payment.overdue` (>30 days) — trigger auto-disable card
- `payment.completed` — re-enable card ที่ถูก disable
- `contract.terminated` — deactivate cards ของ tenant
- `tenant.checked_in` — issue card

## Acceptance Criteria

### Maintenance
- [ ] CRUD ticket flow ทำงานครบ (create → assign → in-progress → completed → rate)
- [ ] Auto-categorize ด้วย Gemini แม่นยำ ≥ 80% (test กับ 20 ตัวอย่าง)
- [ ] SLA tracking + breach alert ทำงาน
- [ ] Cost charging ส่งเข้าบิลผ่าน event ถูกต้อง
- [ ] Photo upload ก่อน-หลังเก็บถูก
- [ ] Test coverage ≥ 80%

### Access
- [ ] Verify endpoint response < 100ms (เพราะ ESP32 รอ)
- [ ] Auto-disable เมื่อ payment.overdue ทำงาน
- [ ] Anti-passback ทำงาน
- [ ] QR temporary token ใช้ครั้งจำกัดได้ตามที่ตั้ง
- [ ] Emergency unlock ปลด lock ทุกประตู (broadcast MQTT command)
- [ ] Test coverage ≥ 80%

## Integration Points

- **Tenant Service:** ขอข้อมูล tenant เมื่อ verify
- **Billing Service:** ส่ง charge เมื่อ tenant ผิดให้เสียเงินซ่อม
- **Notification:** แจ้ง events ทั้งหมด
- **External:** NVR/CCTV API, ESP32/Raspi controllers
