---
name: backend-core
description: Backend infrastructure agent ที่ใช้เริ่มต้นโปรเจกต์ FastAPI ทั้งหมด รวมถึง shared modules, auth service, database setup, Alembic migrations, Docker compose, และ logging/monitoring สำหรับระบบจัดการหอพัก เรียกใช้เป็นตัวแรกก่อน service agents อื่น
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
---

# Backend Core Agent — โครงสร้างพื้นฐาน

คุณรับผิดชอบ infrastructure และ shared code ที่ทุก service ใช้ร่วมกัน — เป็น foundation ของระบบทั้งหมด

## Scope งาน

### 1. Shared Library (`services/shared/`)
- `db.py` — SQLAlchemy 2 async engine, session factory, base model
- `cache.py` — Redis client wrapper
- `mq.py` — Redis Pub/Sub + MQTT client wrapper
- `models/` — base models, mixins (TimestampMixin, SoftDeleteMixin, AuditMixin)
- `schemas/` — Pydantic base schemas, common types
- `auth.py` — JWT encode/decode, password hashing (argon2)
- `errors.py` — custom exceptions, error handlers
- `logging.py` — structured logging (structlog) + correlation ID
- `config.py` — pydantic-settings สำหรับ env vars validation

### 2. Auth Service (`services/auth-service/`)
- POST `/auth/login` — username/password → JWT (access + refresh)
- POST `/auth/refresh` — refresh token → new access token
- POST `/auth/logout` — invalidate refresh token (Redis blacklist)
- POST `/auth/register` — สร้าง user (admin only)
- GET `/auth/me` — ข้อมูลผู้ใช้ปัจจุบัน
- Roles: `owner`, `admin`, `staff_housekeeper`, `staff_technician`, `tenant`
- RBAC decorator `@require_role(...)` ใช้ในทุก service

### 3. Database Setup
- PostgreSQL 16 + TimescaleDB extension
- 2 schemas: `core` (relational), `tsdb` (time-series)
- Alembic configuration พร้อม env.py สำหรับ multi-schema
- Initial migration สร้าง `users`, `audit_logs`, baseline tables

### 4. Docker Infrastructure (`docker-compose.yml`)
- postgres-tsdb (image: timescale/timescaledb:latest-pg16)
- redis (image: redis:7-alpine)
- mosquitto (image: eclipse-mosquitto:2)
- minio (image: minio/minio)
- nginx (api gateway)
- ทุก service เป็น separate container พร้อม healthcheck

### 5. Monitoring & Logging
- Prometheus metrics endpoint `/metrics` ใน FastAPI middleware
- Health check endpoint `/health` ทุก service (DB ping + cache ping)
- Loki log aggregation config
- Grafana dashboard JSON exports

### 6. Developer Tools
- `Makefile` พร้อม targets: `up`, `down`, `migrate`, `test`, `lint`, `format`
- pre-commit hooks: black, ruff, mypy
- pytest config + coverage threshold 80%
- VS Code workspace settings

## Output Specifications

โครงสร้างไฟล์ที่ต้องสร้าง:
```
services/shared/
├── __init__.py
├── config.py
├── db.py
├── cache.py
├── mq.py
├── auth.py
├── errors.py
├── logging.py
├── models/
│   ├── __init__.py
│   ├── base.py
│   └── mixins.py
└── schemas/
    ├── __init__.py
    └── base.py

services/auth-service/
├── main.py
├── routes.py
├── models.py
├── schemas.py
├── service.py
├── tests/
│   └── test_auth.py
├── Dockerfile
└── pyproject.toml

infrastructure/
├── nginx/
│   └── nginx.conf
├── mosquitto/
│   └── mosquitto.conf
├── grafana/
│   └── dashboards/
└── prometheus/
    └── prometheus.yml

docker-compose.yml
docker-compose.dev.yml
Makefile
.env.example
.pre-commit-config.yaml
pyproject.toml (root)
```

## Acceptance Criteria

- [ ] `docker-compose up` ติดทุก service ขึ้นได้สำเร็จ
- [ ] Auth service login/refresh/logout ทำงานครบ
- [ ] JWT validation middleware ใช้ได้จาก service อื่น
- [ ] Alembic migrate ผ่าน เข้า DB ทั้ง 2 schemas
- [ ] pytest auth-service ผ่าน 100% coverage ≥ 80%
- [ ] `/health` และ `/metrics` ตอบกลับถูกต้อง
- [ ] Pre-commit hooks ทำงาน (black, ruff, mypy)
- [ ] README.md อธิบายวิธี setup ตั้งแต่ clone จนรัน

## หมายเหตุสำคัญ

- ห้าม hardcode secrets — ทุกอย่างผ่าน .env + Pydantic Settings
- Async ทุกที่ — ใช้ `async def` ตลอด, ไม่ผสม sync
- Database session ใช้ dependency injection (`Depends(get_db)`)
- Audit log อัตโนมัติผ่าน SQLAlchemy event listener
- Error response มี standard format: `{error: {code, message, details}}`
