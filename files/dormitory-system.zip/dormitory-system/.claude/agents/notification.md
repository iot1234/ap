---
name: notification
description: สร้าง Notification Service เป็น hub กลางที่รับ events จากทุก service แล้วส่งข้อความผ่าน LINE Messaging API, Email (SendGrid), SMS, FCM Push เป็นหลัก รวมถึง Report Service ที่ทำ analytics dashboards และ export Excel/PDF สำหรับเจ้าของหอพัก
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
---

# Notification & Report Service Agent

รับผิดชอบ 2 services ที่ทำหน้าที่ output ของระบบ — แจ้งเตือนและรายงาน

---

# PART 1: Notification Service

## Database Models

### `notifications`
- id (UUID PK), recipient_id (tenant or user), recipient_type
- channel (enum: line, email, sms, push, in_app)
- template_id (FK), event_type (e.g., 'bill.created')
- subject, body, payload (JSON for rich message)
- status (enum: queued, sending, sent, delivered, failed, read)
- attempt_count, last_error
- scheduled_at, sent_at, delivered_at, read_at
- external_id (LINE message id, SendGrid id, etc.)

### `notification_templates`
- id, name (unique), language (default 'th')
- channel, subject_template (Jinja2), body_template
- variables_schema (JSON Schema validation)
- is_active

### `notification_preferences`
- user_id (PK), email_enabled, sms_enabled, push_enabled, line_enabled
- quiet_hours_start, quiet_hours_end
- categories_enabled (JSON: bill, maintenance, access, marketing)

### `notification_broadcasts`
- id, target_filter (JSON), template_id, total_count, sent_count
- created_by, sent_at

## Channels

### LINE Messaging API
- ใช้ line-bot-sdk
- รองรับ Flex Message สำหรับบิล (รูปบิล + ปุ่ม + QR)
- Rich Menu สำหรับ tenant: ดูบิล / แจ้งซ่อม / ติดต่อแอดมิน

### Email (SendGrid)
- ใช้ MJML สำหรับ responsive email templates
- Track open + click

### SMS (Twilio หรือ Thai SMS gateway)
- ใช้สำหรับ critical alerts เท่านั้น (ค่าใช้จ่ายสูง)

### FCM Push
- สำหรับ Mobile App
- Topic-based: subscribe เป็น `tenant_{id}` หรือ `building_{id}`

## API Endpoints

- POST `/api/notify/send` — ส่งข้อความตรง (admin only)
- POST `/api/notify/template/{name}` — ส่งโดยใช้ template
- POST `/api/notify/broadcast` — ส่งทั้งอาคาร/ทั้งชั้น
- GET `/api/notify/history?recipient_id=`
- GET `/api/notify/templates`
- POST `/api/notify/templates` — สร้าง/แก้ template
- PUT `/api/notify/preferences` — ผู้ใช้แก้ preference ตัวเอง
- POST `/api/notify/webhook/line` — LINE webhook (รับ message จาก tenant)
- POST `/api/notify/webhook/sendgrid` — delivery status
- GET `/api/notify/stats?from=&to=`

## Event-driven Flow

```python
# Event listener ใน notification service
@subscribe('bill.created')
async def handle_bill_created(event):
    bill_id = event['bill_id']
    bill = await fetch_bill(bill_id)
    tenant = await fetch_tenant(bill['tenant_id'])

    # Smart routing
    if tenant.line_user_id and prefs.line_enabled:
        await send_line(
            user_id=tenant.line_user_id,
            template='bill_created',
            variables={'bill': bill, 'tenant': tenant}
        )
    elif tenant.email and prefs.email_enabled:
        await send_email(...)

    # Logging
    await save_notification_record(...)
```

## Standard Templates ที่ต้องสร้าง

| Template Name | Channel | Trigger Event |
|---------------|---------|---------------|
| bill_created | LINE Flex | bill.created |
| bill_overdue_reminder | LINE | bill.overdue |
| payment_received | LINE | payment.completed |
| receipt_generated | LINE/Email | receipt.generated |
| contract_expiring_30d | LINE | contract.expiring_soon |
| contract_expiring_7d | LINE+SMS | contract.expiring_soon (urgent) |
| meter_anomaly | LINE | meter.anomaly_detected |
| maintenance_assigned | LINE+Push | maintenance.assigned |
| maintenance_completed | LINE | maintenance.completed |
| access_blocked_overdue | LINE | access.denied (reason=overdue) |
| broadcast_water_outage | LINE | manual (broadcast) |
| welcome | LINE+Email | tenant.checked_in |
| checkout_summary | Email | tenant.checked_out |

## LINE Bot Webhook Handler

รับ webhook จาก LINE → แยกประเภท:
- "ดูบิล" → ส่ง Flex message รายการบิล active
- "แจ้งซ่อม" → ส่ง Quick Reply เลือก category, จากนั้นรับข้อความ + รูป → call maintenance service
- "สถานะการชำระ" → ส่งสรุป
- ข้อความอื่น → forward to admin chat

## Quiet Hours Logic

ถ้าเวลาปัจจุบันอยู่ใน quiet hours ของผู้รับ + notification ไม่ใช่ critical:
- เลื่อนส่งไปหลัง quiet_hours_end
- เก็บ scheduled_at ไว้ในฐานข้อมูล Celery beat รัน

## Acceptance Criteria — Notification

- [ ] ทุก template render ถูกต้อง ภาษาไทยไม่เพี้ยน
- [ ] LINE Flex Message สวยงาม กดปุ่มได้
- [ ] Quiet hours respect ทำงาน
- [ ] Retry logic — fail แล้ว retry 3 ครั้ง back-off
- [ ] Webhook LINE process ได้ทุก event type
- [ ] Broadcast ส่ง 100+ ข้อความได้ภายใน 1 นาที
- [ ] Test coverage ≥ 80% (mock LINE/SendGrid clients)

---

# PART 2: Report Service

## Endpoints

### Financial Reports
- GET `/api/reports/revenue?from=&to=&group_by=month` — รายได้
- GET `/api/reports/revenue/forecast` — ทำนายเดือนหน้า (ใช้ Random Forest)
- GET `/api/reports/aged-receivable` — ค้างชำระ
- GET `/api/reports/expense-tracking` — ค่าใช้จ่ายซ่อม

### Operations Reports
- GET `/api/reports/occupancy?from=&to=` — อัตราเข้าพัก
- GET `/api/reports/turnover` — เข้า-ออก ผู้เช่า
- GET `/api/reports/maintenance-stats` — สรุปงานซ่อม + SLA
- GET `/api/reports/access-frequency` — ความถี่การเข้า-ออก

### Energy Reports
- GET `/api/reports/energy/per-room?period=` — ค่าไฟแยกห้อง
- GET `/api/reports/energy/comparison` — เปรียบเทียบเดือนก่อน
- GET `/api/reports/energy/anomalies` — ห้องที่ใช้ผิดปกติ

### Export
- POST `/api/reports/export/excel` — รับ {report_type, params} → ส่ง URL
- POST `/api/reports/export/pdf` — สรุปสำหรับเจ้าของ (monthly summary)

### Custom Builder
- POST `/api/reports/custom` — รับ SQL-like JSON spec → run
- GET `/api/reports/saved` — saved reports
- POST `/api/reports/saved` — บันทึก custom report

## Architecture

```
Report Service
├── aggregators/         ← async functions ที่ aggregate ข้อมูลจากแต่ละ service
│   ├── billing.py
│   ├── tenant.py
│   ├── meter.py
│   └── maintenance.py
├── exporters/
│   ├── excel.py        ← openpyxl, มี formatting สวยงาม
│   └── pdf.py          ← WeasyPrint
├── ml/
│   └── revenue_forecast.py   ← scikit-learn Random Forest
└── routes.py
```

## Excel Export Format

ทุก export ต้องมี:
- Header row พร้อมชื่อบริษัท + วันที่ generate
- Frozen first row + bold
- Number format ภาษาไทย (1,234.56 ฿)
- Auto column width
- Conditional formatting (สีแดงสำหรับค้างชำระ > 60 วัน)

## PDF Monthly Summary

หน้าเดียวสำหรับเจ้าของ:
- Logo + ชื่อหอพัก
- KPI cards: รายได้, occupancy, ค่าใช้จ่าย, กำไร
- กราฟรายได้ 12 เดือนย้อนหลัง
- ตารางห้องที่ค้างชำระ
- Top 5 ห้องใช้ไฟเยอะ

## Forecast Model (revenue)

Features: month, year, occupancy_rate, season, holiday_count, prev_3m_avg
Target: total_revenue
Algorithm: Random Forest Regressor
Retrain: ทุกเดือนหลัง period closing

## Acceptance Criteria — Report

- [ ] ทุก report endpoint ตอบกลับใน < 2 วินาที
- [ ] Excel format สวยงาม เปิดใน Google Sheets ได้
- [ ] PDF monthly summary หน้าเดียวอ่านง่าย
- [ ] Forecast model RMSE < 10% ของ mean
- [ ] Custom report builder validate input safety (SQL injection prevention)
- [ ] Cache aggregations ใน Redis สำหรับ heavy queries
- [ ] Test coverage ≥ 80%

## Integration Points

- ทุก service (read-only data access)
- Frontend Web (Chart.js สำหรับ render)
