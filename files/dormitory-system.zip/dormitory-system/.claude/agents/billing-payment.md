---
name: billing-payment
description: สร้าง Billing Service และ Payment Service สำหรับออกบิลค่าเช่า/ค่าน้ำ/ค่าไฟอัตโนมัติ, สร้าง PromptPay QR, รับ webhook จากธนาคาร, ทำ reconciliation, OCR สลิปโอนเงิน, และจัดการ aged receivable เรียกใช้หลัง backend-core เสร็จ
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
---

# Billing & Payment Service Agent

รับผิดชอบ 2 services ที่เกี่ยวข้องกัน — Billing (ออกบิล) และ Payment (รับชำระ)

## Database Models

### `bills`
- id (UUID PK), bill_number (BILL-YYYYMM-NNNN unique)
- contract_id (FK), tenant_id (FK), room_id (FK)
- billing_period (DATE: first day of month)
- issue_date, due_date, total_amount, paid_amount, balance
- status (enum: draft, issued, partially_paid, paid, overdue, void)
- pdf_s3_key, qr_payload, qr_image_s3_key
- late_fee_amount, discount_amount, vat_amount
- created_at, updated_at

### `bill_items`
- id, bill_id (FK), item_type (enum: rent, electricity, water, internet, parking, maintenance, late_fee, discount, other)
- description, quantity, unit, unit_price, amount
- meter_start, meter_end (สำหรับค่าไฟ/น้ำ)
- created_at

### `payments`
- id (UUID PK), payment_number, bill_id (FK)
- amount, payment_method (enum: promptpay, bank_transfer, cash, credit_card)
- bank_ref (transaction ref จากธนาคาร)
- slip_s3_key, slip_ocr_data (JSON)
- status (enum: pending, verified, failed, refunded)
- verified_by (user_id หรือ 'system_webhook')
- paid_at, verified_at, created_at

### `rate_tables`
- id, name (default, premium_floor, etc.), effective_from
- electricity_rate, water_rate, vat_rate, late_fee_rate
- service_charge, internet_fee, parking_fee

### `recurring_charges`
- id, contract_id (FK), charge_type, amount, frequency
- start_date, end_date, is_active

## Billing Service Endpoints

- POST `/api/bills/generate` — สร้างบิลทั้งหอ (Celery task รายเดือน)
- POST `/api/bills/generate/{contract_id}` — สร้างบิลเฉพาะรายการ
- GET `/api/bills?period=&status=&tenant_id=`
- GET `/api/bills/{id}` — บิลพร้อม items
- GET `/api/bills/{id}/pdf` — ดาวน์โหลด PDF
- POST `/api/bills/{id}/items` — เพิ่ม item พิเศษ (admin)
- PUT `/api/bills/{id}/discount` — ใส่ส่วนลด
- POST `/api/bills/{id}/void` — ยกเลิกบิล (with reason)
- GET `/api/bills/aged-receivable` — รายงานค้างชำระแยกอายุ
- GET `/api/bills/summary?period=` — สรุปยอดเดือน

## Payment Service Endpoints

- POST `/api/payments/qr` — สร้าง PromptPay QR สำหรับบิล
- POST `/api/payments/cash` — บันทึกชำระเงินสด (admin only)
- POST `/api/payments/slip-upload` — รับสลิป → OCR Gemini → match
- POST `/api/payments/webhook/scb` — webhook จาก SCB Easy
- POST `/api/payments/webhook/kbank` — webhook จาก K-Bank
- POST `/api/payments/{id}/refund` — คืนเงิน (admin only)
- GET `/api/payments?bill_id=&from=&to=`
- GET `/api/payments/{id}/receipt-pdf`
- POST `/api/payments/reconcile` — manual reconciliation tool

## Business Logic

### Bill Generation (รายเดือนทุกวันที่ 1)
```
สำหรับแต่ละ contract ที่ active:
  1. ดึงค่ามิเตอร์เดือนที่แล้ว (request meter-service)
  2. คำนวณหน่วยที่ใช้ = current - previous
  3. คิดค่าไฟ = หน่วย × rate (จาก rate_tables)
  4. สร้าง bill_items:
     - ค่าเช่า (จาก contract.monthly_rent)
     - ค่าไฟ (จากมิเตอร์)
     - ค่าน้ำ (เหมาจ่ายจาก rate_tables)
     - ค่าอินเทอร์เน็ต / ที่จอดรถ (ถ้ามี recurring_charges)
     - ส่วนลด (ถ้ามี)
     - VAT 7%
  5. รวมยอด → สร้าง bill
  6. Generate PromptPay QR
  7. Generate PDF invoice
  8. ส่ง event `bill.created` → notification-service ส่ง LINE
```

### PromptPay QR
- ใช้ library `pythai-promptpay` หรือ implement EMV QR spec
- ใช้เลขบัญชีเจ้าของหอ + ยอดเงิน + reference1=bill_number
- QR ต้อง expire ใน 24 ชม., regen ได้

### Slip OCR (Gemini)
```python
prompt = """อ่านข้อมูลจากสลิปโอนเงินนี้:
- จำนวนเงิน
- เวลาที่โอน
- ธนาคารต้นทาง
- ชื่อผู้โอน
- เลขอ้างอิงรายการ
ตอบในรูป JSON: {amount, datetime, source_bank, sender_name, ref}"""
```
จากนั้น match กับ bills ที่ status = issued หรือ overdue โดย:
- amount ตรง
- ref = bill_number หรือ tenant_id
- datetime อยู่ในช่วง 24 ชม.

### Webhook Reconciliation
- รับ payload → verify signature
- หา bill ที่ ref ตรงกัน, amount ตรงกัน
- ถ้าตรง → mark paid, ส่ง event `payment.completed`
- ถ้าไม่เจอ → push เข้า manual review queue

### Late Fee
- Celery task รายวัน หาบิลที่ due_date < today, status = issued
- คำนวณดอกเบี้ย = balance × late_fee_rate × (days_overdue / 30)
- เพิ่ม bill_item type = late_fee
- ส่ง event `bill.overdue` → notification

### Receipt
- Generate PDF เมื่อ payment status = verified
- ส่งให้ tenant ผ่าน LINE

## Events

### Publish
- `bill.created`, `bill.overdue`, `bill.voided`, `bill.partially_paid`
- `payment.completed`, `payment.failed`, `payment.refunded`
- `receipt.generated`

### Subscribe
- `meter.month_closed` — trigger bill generation
- `contract.terminated` — สร้างบิลสุดท้าย
- `contract.created` — เก็บข้อมูล recurring charges

## Acceptance Criteria

- [ ] Bill generation ทำงานได้ — รัน manually กับ contract test ออกบิลถูกต้อง
- [ ] PDF invoice สวยงาม ภาษาไทย QR PromptPay สแกนได้จริง
- [ ] Webhook handler verify signature ถูก, idempotent
- [ ] Slip OCR ทดสอบกับสลิป SCB/KBank ได้ผลถูกต้อง ≥ 90%
- [ ] Aged receivable report แสดง 0-30, 31-60, 61-90, 90+ ถูกต้อง
- [ ] Late fee คำนวณถูก
- [ ] Refund flow ครบ
- [ ] Test coverage ≥ 80%
- [ ] Idempotency key ใน POST /payments/* ทำงาน

## Integration Points

- **Meter Service:** ดึง meter readings สำหรับคำนวณค่าไฟ
- **Tenant Service:** ดึง contract details
- **Notification:** ส่ง LINE/Email บิล + ใบเสร็จ
- **External:** SCB Easy API, K-Bank API, Gemini Vision API
